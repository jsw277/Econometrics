# Data_Science_Fundamentals

**Objective:** to introduce Data Science concepts from both a theoretical and practical standpoint, all in Python.

**Audience:** ranges from beginner to intermediate.

**Note:** this is a living repository that will be updated quite frequently.
